
Gauss6500 机械臂

[产品主页](http://gauss.tonyrobotics.com/ "产品主页")  

[淘宝店铺](https://item.taobao.com/item.htm?spm=a230r.1.14.1.46962f47OKzNW6&id=586250996678&ns=1&abbucket=10#detail "淘宝店铺")

[开发文档](https://www.kancloud.cn/itfanr/gauss_doc_1/971823 "开发文档")

[知乎专栏](https://zhuanlan.zhihu.com/c_1086677718430425088 "知乎专栏")

[相关博客](https://blog.csdn.net/itfanr/article/details/87078352)

机械臂在 Gazebo 的仿真界面： 
![gauss_gazebo](gauss6500/img/gauss_gazebo.png)

机械臂在 RViz 的仿真界面：
![gauss_rviz](gauss6500/img/gauss_rviz.png)

# 报错解决方法
添加包 household_objects_database_msgs

image_common

manipulation_msgs

** error: call of overloaded 'abs(uint32_t)' is ambiguous**

/home/richardurben/catkin_ws/src/gauss-robot/gauss_driver/src/communication/dxl_communication.cpp

abs()函数->abs(float()) :smile:

