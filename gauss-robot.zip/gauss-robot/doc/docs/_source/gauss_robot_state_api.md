# 状态查看接口

## 关节状态接口

- /joint_states
- ROS 接口类型: Topic
- 接口内容: sensor_msgs/JointState

## 空间位置接口

- /gauss/robot_state
- ROS 接口类型: Topic
- 接口内容: gauss_msgs/RobotState

