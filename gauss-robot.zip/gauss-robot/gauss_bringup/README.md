run_on_system_start

/etc/systemd/system/multi-user.target.wants/gauss-ros.service
