#!/usr/bin/env python

class GaussFileException(Exception):
    pass
