#!/usr/bin/env python

class TrajectoryCommandType:
    GET = 1
    CREATE = 2
    UPDATE = 3
    DELETE = 4
    
