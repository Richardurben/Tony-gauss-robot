#!/usr/bin/env python


class SequenceActionType:
    
    EXECUTE_FROM_ID     = 1
    EXECUTE_FROM_XML    = 2
    EXECUTE_FROM_PYTHON = 3 # Not yet implemented
