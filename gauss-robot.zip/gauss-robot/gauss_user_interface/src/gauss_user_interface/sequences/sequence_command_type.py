#!/usr/bin/env python

class SequenceCommandType:
    
    GET               = 1
    CREATE            = 2
    UPDATE            = 3
    DELETE            = 4
    GET_LAST_EXECUTED = 5
