^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package household_objects_database_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.2 (2016-07-19)
------------------
* [feat] added ORK type field in DatabaseModelPose `#1 <https://github.com/ros-interactive-manipulation/household_objects_database_msgs/issues/1>`_
* Updated maintainers
* Contributors: Matei Ciocarlie, Dave Coleman, Isaac I.Y. Saito

0.1.1 (2013-03-15)
------------------
* tagged 0.1.1 version
* added ORK type field in DatabaseModelPose
* Contributors: Matei Ciocarlie

0.1.0 (2013-03-05)
------------------
* Initial commit; moved files over from household_objects_database package in object_manipulation
* Contributors: Matei Ciocarlie
